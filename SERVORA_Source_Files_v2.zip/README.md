# SERVORA

SERVORA is a customizable appointment-booking and business-management starter built with React, TypeScript, Vite and Supabase.

## Features included
- Public service catalogue
- Customer registration and login
- Appointment booking
- Customer booking history
- Admin dashboard and booking status management
- Service management
- Business settings
- Supabase database with Row Level Security
- Responsive black-and-gold interface

## Requirements
- Node.js 20+
- A Supabase project
- GitHub account

## Run locally
1. Clone this repository.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add your Supabase project URL and anon key.
5. Run the SQL migration in `supabase/migrations/001_initial_schema.sql` using Supabase SQL Editor.
6. Create the first admin by registering a user, then promote that user using the secure SQL instructions in `docs/INSTALLATION.md`.
7. Run `npm run dev`.

## Build
Run `npm run build`, then deploy the `dist` directory to a Vite-compatible host.

## Security
Never put a Supabase service-role key in browser code. The SQL migration enables RLS. Review policies and test with separate customer and administrator accounts before production use.

## Important
This is a functional starter foundation, not a fully audited payment or multi-tenant SaaS product. Payment processing, email/SMS notifications, employee scheduling and production monitoring require separate provider setup and testing.
