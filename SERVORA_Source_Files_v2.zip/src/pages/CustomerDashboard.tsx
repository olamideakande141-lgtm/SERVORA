import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { requireSupabase } from "../lib/supabase";
import { useNavigate } from "react-router-dom";

type Booking = { id: string; service_name: string; appointment_date: string; appointment_time: string; status: string; amount: number };

export default function CustomerDashboard() {
  const { user } = useAuth(); const [bookings,setBookings] = useState<Booking[]>([]); const [loading,setLoading] = useState(true); const navigate=useNavigate();
  useEffect(() => { if(!user) return; requireSupabase().from("bookings").select("id,service_name,appointment_date,appointment_time,status,amount").eq("customer_id",user.id).order("created_at",{ascending:false}).then(({data})=>{setBookings(data??[]);setLoading(false);}); },[user]);
  const logout=async()=>{await requireSupabase().auth.signOut();navigate("/");};
  return <section className="section page-section"><div className="page-heading"><div><span className="eyebrow gold">CUSTOMER SPACE</span><h1 className="page-title">My <em>appointments</em></h1></div><button className="button button-outline" onClick={logout}>Sign out</button></div>
    {loading?<p>Loading your bookings…</p>:bookings.length===0?<div className="empty-state">You have no bookings yet. <a href="/book">Book your first service.</a></div>:<div className="table-wrap"><table><thead><tr><th>Service</th><th>Date</th><th>Time</th><th>Amount</th><th>Status</th></tr></thead><tbody>{bookings.map(b=><tr key={b.id}><td>{b.service_name}</td><td>{b.appointment_date}</td><td>{b.appointment_time}</td><td>{Number(b.amount).toFixed(2)}</td><td><span className={`status ${b.status}`}>{b.status}</span></td></tr>)}</tbody></table></div>}
  </section>;
}
