import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { requireSupabase } from "../lib/supabase";

type Service = { id: string; name: string; description: string | null; price: number; duration_minutes: number; category: string | null };

export default function Services() {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    requireSupabase().from("services").select("id,name,description,price,duration_minutes,category").eq("active", true).order("created_at", { ascending: false })
      .then(({ data }) => { setServices(data ?? []); setLoading(false); });
  }, []);
  return <section className="section page-section"><span className="eyebrow gold">WHAT WE OFFER</span><h1 className="page-title">Our <em>services</em></h1>
    {loading ? <p>Loading services…</p> : services.length === 0 ? <div className="empty-state">No services have been published yet. An administrator can add services from the dashboard.</div> :
      <div className="service-grid">{services.map(s => <article className="service-card" key={s.id}><span className="eyebrow gold">{s.category || "SERVICE"}</span><h3>{s.name}</h3><p>{s.description}</p><div className="service-meta"><strong>{s.price.toFixed(2)}</strong><span>{s.duration_minutes} min</span></div><Link className="text-link" to={`/book?service=${s.id}`}>Book this service →</Link></article>)}</div>}
  </section>;
}
