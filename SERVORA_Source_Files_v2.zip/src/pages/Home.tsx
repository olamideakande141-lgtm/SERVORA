import { ArrowUpRight, CalendarCheck, ShieldCheck, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";

const highlights = [
  { icon: CalendarCheck, title: "Effortless booking", text: "Let customers request appointments online, at any time." },
  { icon: ShieldCheck, title: "One clear workspace", text: "Keep customer details and appointment updates organized." },
  { icon: Sparkles, title: "A polished presence", text: "Present your services with a professional, mobile-ready website." }
];

export default function Home() {
  return <div>
    <section className="hero">
      <div className="hero-copy">
        <span className="eyebrow gold">A BETTER WAY TO RUN YOUR SERVICE BUSINESS</span>
        <h1>Make every<br/><em>appointment</em><br/>count.</h1>
        <p>Give customers a simple way to discover your services and request a booking, while your team manages everything in one place.</p>
        <div className="hero-actions"><Link className="button" to="/book">Book a service <ArrowUpRight size={18}/></Link><Link className="text-link" to="/services">Explore services</Link></div>
        <div className="hero-note"><span className="gold-dot"/> Thoughtfully designed for service businesses</div>
      </div>
      <div className="hero-visual">
        <div className="visual-card visual-main"><span className="eyebrow">THE SERVORA EXPERIENCE</span><div className="visual-number">01<span>/03</span></div><h3>Service, elevated.</h3><p>Professional care, thoughtfully scheduled.</p><div className="gold-line"/></div>
        <div className="visual-card visual-float"><span className="gold-dot"/> Booking made simple</div>
      </div>
    </section>
    <section className="section">
      <div className="section-heading"><span className="eyebrow gold">BUILT AROUND YOUR BUSINESS</span><h2>More than a website.<br/><em>A smoother way to work.</em></h2></div>
      <div className="feature-grid">{highlights.map(({icon: Icon,title,text}) => <article className="feature-card" key={title}><Icon className="gold-icon"/><h3>{title}</h3><p>{text}</p></article>)}</div>
    </section>
    <section className="cta-band"><div><span className="eyebrow gold">READY WHEN YOU ARE</span><h2>Let's get your next booking started.</h2></div><Link className="button" to="/book">Book now <ArrowUpRight size={18}/></Link></section>
  </div>;
}
