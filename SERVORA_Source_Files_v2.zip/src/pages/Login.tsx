import { FormEvent, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { requireSupabase } from "../lib/supabase";

export default function Login() {
  const [email,setEmail] = useState(""); const [password,setPassword] = useState("");
  const [error,setError] = useState(""); const [busy,setBusy] = useState(false); const navigate = useNavigate();
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setError("");
    const { error } = await requireSupabase().auth.signInWithPassword({ email, password });
    setBusy(false); if (error) setError(error.message); else navigate("/account");
  };
  return <section className="section page-section narrow"><span className="eyebrow gold">WELCOME BACK</span><h1 className="page-title">Sign <em>in</em></h1><form className="form-card" onSubmit={submit}>
    <label>Email<input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></label>
    <label>Password<input type="password" required value={password} onChange={e=>setPassword(e.target.value)}/></label>
    {error && <p className="error">{error}</p>}<button className="button button-full" disabled={busy}>{busy?"Signing in…":"Sign in"}</button>
    <button type="button" className="text-button" onClick={async()=>{if(!email){setError("Enter your email first.");return;} const {error}=await requireSupabase().auth.resetPasswordForEmail(email);setError(error?.message ?? "If the account exists, a reset email will be sent.");}}>Forgot password?</button>
    <p className="muted">New here? <Link to="/register">Create an account</Link></p>
  </form></section>;
}
