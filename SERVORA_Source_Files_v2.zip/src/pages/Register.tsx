import { FormEvent, useState } from "react";
import { Link } from "react-router-dom";
import { requireSupabase } from "../lib/supabase";

export default function Register() {
  const [name,setName] = useState(""); const [email,setEmail] = useState(""); const [password,setPassword] = useState("");
  const [message,setMessage] = useState(""); const [busy,setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setMessage("");
    const { error } = await requireSupabase().auth.signUp({ email, password, options: { data: { full_name: name } } });
    setBusy(false); setMessage(error?.message ?? "Account created. Check your email if email confirmation is enabled.");
  };
  return <section className="section page-section narrow"><span className="eyebrow gold">JOIN SERVORA</span><h1 className="page-title">Create an <em>account</em></h1><form className="form-card" onSubmit={submit}>
    <label>Full name<input required value={name} onChange={e=>setName(e.target.value)}/></label>
    <label>Email<input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></label>
    <label>Password<input type="password" minLength={8} required value={password} onChange={e=>setPassword(e.target.value)}/></label>
    {message && <p className="form-message">{message}</p>}<button className="button button-full" disabled={busy}>{busy?"Creating…":"Create account"}</button>
    <p className="muted">Already registered? <Link to="/login">Sign in</Link></p>
  </form></section>;
}
