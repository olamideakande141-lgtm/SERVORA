import { useEffect, useState } from "react";
import { requireSupabase } from "../../lib/supabase";
type Profile={id:string;full_name:string|null;email:string|null;created_at:string};
export default function Customers(){const [rows,setRows]=useState<Profile[]>([]);const [error,setError]=useState("");
useEffect(()=>{requireSupabase().from("profiles").select("id,full_name,email,created_at").eq("role","customer").order("created_at",{ascending:false}).then(({data,error})=>{setRows(data??[]);if(error)setError(error.message);});},[]);
return <><span className="eyebrow gold">RELATIONSHIPS</span><h1 className="page-title">Your <em>customers</em></h1>{error&&<p className="error">{error}</p>}<div className="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Joined</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{r.full_name||"—"}</td><td>{r.email||"—"}</td><td>{new Date(r.created_at).toLocaleDateString()}</td></tr>)}</tbody></table></div></>;}
