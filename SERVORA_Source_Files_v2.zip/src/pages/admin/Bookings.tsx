import { useEffect, useState } from "react";
import { requireSupabase } from "../../lib/supabase";

type Booking={id:string;service_name:string;appointment_date:string;appointment_time:string;status:string;phone:string|null;amount:number};
const statuses=["pending","confirmed","in_progress","completed","cancelled"];
export default function Bookings(){
 const [rows,setRows]=useState<Booking[]>([]);const [error,setError]=useState("");
 const load=async()=>{const {data,error}=await requireSupabase().from("bookings").select("id,service_name,appointment_date,appointment_time,status,phone,amount").order("created_at",{ascending:false});if(error)setError(error.message);setRows(data??[]);};
 useEffect(()=>{void load();},[]);
 const update=async(id:string,status:string)=>{const {error}=await requireSupabase().from("bookings").update({status}).eq("id",id);if(error)setError(error.message);else void load();};
 return <><span className="eyebrow gold">OPERATIONS</span><h1 className="page-title">Manage <em>bookings</em></h1>{error&&<p className="error">{error}</p>}<div className="table-wrap"><table><thead><tr><th>Service</th><th>Date</th><th>Time</th><th>Phone</th><th>Amount</th><th>Status</th><th>Update</th></tr></thead><tbody>{rows.map(b=><tr key={b.id}><td>{b.service_name}</td><td>{b.appointment_date}</td><td>{b.appointment_time}</td><td>{b.phone}</td><td>{Number(b.amount).toFixed(2)}</td><td>{b.status}</td><td><select value={b.status} onChange={e=>void update(b.id,e.target.value)}>{statuses.map(s=><option key={s} value={s}>{s}</option>)}</select></td></tr>)}</tbody></table></div></>;
}
