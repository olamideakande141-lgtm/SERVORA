import { useEffect, useState } from "react";
import { CalendarDays, Users, CheckCircle2, Clock } from "lucide-react";
import { requireSupabase } from "../../lib/supabase";

export default function AdminDashboard() {
  const [stats,setStats] = useState({bookings:0,pending:0,confirmed:0,customers:0});
  useEffect(()=>{ const load=async()=>{const db=requireSupabase(); const [b,p,c,u]=await Promise.all([
    db.from("bookings").select("*",{count:"exact",head:true}),
    db.from("bookings").select("*",{count:"exact",head:true}).eq("status","pending"),
    db.from("bookings").select("*",{count:"exact",head:true}).eq("status","confirmed"),
    db.from("profiles").select("*",{count:"exact",head:true}).eq("role","customer")
  ]);setStats({bookings:b.count??0,pending:p.count??0,confirmed:c.count??0,customers:u.count??0});}; void load(); },[]);
  const cards=[["Total bookings",stats.bookings,CalendarDays],["Pending",stats.pending,Clock],["Confirmed",stats.confirmed,CheckCircle2],["Customers",stats.customers,Users]] as const;
  return <><span className="eyebrow gold">BUSINESS OVERVIEW</span><h1 className="page-title">Good to see you, <em>admin.</em></h1><div className="stats-grid">{cards.map(([label,value,Icon])=><article className="stat-card" key={label}><Icon className="gold-icon"/><span>{label}</span><strong>{value}</strong></article>)}</div><div className="admin-panel"><h2>Welcome to your workspace</h2><p>Use the navigation to manage appointments, customers, services and business settings. Statistics update from your database records.</p></div></>;
}
