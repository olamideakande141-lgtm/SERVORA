import { FormEvent, useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { requireSupabase } from "../lib/supabase";
import { useAuth } from "../context/AuthContext";

type Service = { id: string; name: string; price: number; duration_minutes: number };

export default function Booking() {
  const [params] = useSearchParams();
  const [services, setServices] = useState<Service[]>([]);
  const [serviceId, setServiceId] = useState(params.get("service") ?? "");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("09:00");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    requireSupabase().from("services").select("id,name,price,duration_minutes").eq("active", true)
      .then(({ data }) => setServices(data ?? []));
  }, []);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setMessage("");
    if (!user) { navigate("/login"); return; }
    setBusy(true);
    const selected = services.find(s => s.id === serviceId);
    if (!selected) { setMessage("Please select a service."); setBusy(false); return; }
    const { error } = await requireSupabase().from("bookings").insert({
      customer_id: user.id, service_id: selected.id, service_name: selected.name,
      appointment_date: date, appointment_time: time, phone, address, notes,
      amount: selected.price, status: "pending", payment_status: "unpaid"
    });
    setBusy(false);
    if (error) setMessage(error.message);
    else { setMessage("Your booking request has been submitted."); setTimeout(() => navigate("/account"), 1200); }
  };

  return <section className="section page-section narrow"><span className="eyebrow gold">RESERVE YOUR TIME</span><h1 className="page-title">Book a <em>service</em></h1>
    <form className="form-card" onSubmit={submit}>
      <label>Choose a service<select required value={serviceId} onChange={e => setServiceId(e.target.value)}><option value="">Select service</option>{services.map(s => <option key={s.id} value={s.id}>{s.name} — {s.price.toFixed(2)}</option>)}</select></label>
      <div className="form-row"><label>Date<input required type="date" min={new Date().toISOString().slice(0,10)} value={date} onChange={e => setDate(e.target.value)}/></label><label>Preferred time<input required type="time" value={time} onChange={e => setTime(e.target.value)}/></label></div>
      <label>Phone number<input required value={phone} onChange={e => setPhone(e.target.value)} placeholder="+234…"/></label>
      <label>Service address<input value={address} onChange={e => setAddress(e.target.value)} placeholder="Where should the service take place?"/></label>
      <label>Additional notes<textarea value={notes} onChange={e => setNotes(e.target.value)} rows={3}/></label>
      {message && <p className="form-message">{message}</p>}
      <button className="button button-full" disabled={busy}>{busy ? "Submitting…" : "Request appointment"}</button>
      <small className="muted">Your appointment is pending until the business confirms it.</small>
    </form>
  </section>;
}
