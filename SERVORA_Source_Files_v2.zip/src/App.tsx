import { Navigate, Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import WhatsAppButton from "./components/WhatsAppButton";
import ProtectedRoute from "./components/ProtectedRoute";
import AdminLayout from "./components/AdminLayout";
import { useAuth } from "./context/AuthContext";
import Home from "./pages/Home";
import Services from "./pages/Services";
import Booking from "./pages/Booking";
import Login from "./pages/Login";
import Register from "./pages/Register";
import CustomerDashboard from "./pages/CustomerDashboard";
import AdminDashboard from "./pages/admin/AdminDashboard";
import Bookings from "./pages/admin/Bookings";
import Customers from "./pages/admin/Customers";
import ManageServices from "./pages/admin/ManageServices";
import Settings from "./pages/admin/Settings";

function AdminRedirect(){const {role,loading}=useAuth();if(loading)return <div className="page-center">Loading…</div>;return <Navigate to={role==="admin"?"/admin":"/account"} replace/>;}
export default function App(){
 return <><Navbar/><Routes>
  <Route path="/" element={<Home/>}/><Route path="/services" element={<Services/>}/><Route path="/book" element={<Booking/>}/><Route path="/login" element={<Login/>}/><Route path="/register" element={<Register/>}/>
  <Route path="/account" element={<ProtectedRoute><CustomerDashboard/></ProtectedRoute>}/>
  <Route path="/dashboard" element={<AdminRedirect/>}/>
  <Route path="/admin" element={<ProtectedRoute admin><AdminLayout/></ProtectedRoute>}>
    <Route index element={<AdminDashboard/>}/><Route path="bookings" element={<Bookings/>}/><Route path="customers" element={<Customers/>}/><Route path="services" element={<ManageServices/>}/><Route path="settings" element={<Settings/>}/>
  </Route>
  <Route path="*" element={<main className="section page-section"><h1>Page not found</h1></main>}/>
 </Routes><Footer/><WhatsAppButton/></>;
}
