import { Link, NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, role } = useAuth();
  return <header className="navbar">
    <Link className="brand" to="/"><span className="brand-mark">S</span><span>SERVORA</span></Link>
    <nav>
      <NavLink to="/services">Services</NavLink>
      <NavLink to="/book">Book</NavLink>
      {user ? <NavLink to={role === "admin" ? "/admin" : "/account"}>Dashboard</NavLink> : <NavLink to="/login">Login</NavLink>}
    </nav>
    <Link className="button button-small" to={user ? (role === "admin" ? "/admin" : "/account") : "/register"}>{user ? "My account" : "Get started"}</Link>
  </header>;
}
