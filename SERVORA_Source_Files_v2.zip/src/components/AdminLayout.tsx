import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { LayoutDashboard, CalendarDays, Users, BriefcaseBusiness, Settings, LogOut } from "lucide-react";
import { requireSupabase } from "../lib/supabase";

export default function AdminLayout() {
  const navigate = useNavigate();
  const logout = async () => { await requireSupabase().auth.signOut(); navigate("/"); };
  return <div className="admin-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark">S</span>SERVORA</div>
      <span className="eyebrow">WORKSPACE</span>
      <NavLink to="/admin"><LayoutDashboard size={18}/> Overview</NavLink>
      <NavLink to="/admin/bookings"><CalendarDays size={18}/> Bookings</NavLink>
      <NavLink to="/admin/customers"><Users size={18}/> Customers</NavLink>
      <NavLink to="/admin/services"><BriefcaseBusiness size={18}/> Services</NavLink>
      <NavLink to="/admin/settings"><Settings size={18}/> Settings</NavLink>
      <button className="sidebar-logout" onClick={logout}><LogOut size={18}/> Sign out</button>
    </aside>
    <main className="admin-content"><Outlet /></main>
  </div>;
}
