export default function Footer() {
  return <footer className="footer">
    <div><div className="brand"><span className="brand-mark">S</span>SERVORA</div><p>Thoughtful service. Effortless booking.</p></div>
    <div><strong>Explore</strong><a href="/services">Services</a><a href="/book">Book an appointment</a><a href="/login">Sign in</a></div>
    <small>© {new Date().getFullYear()} SERVORA. Business platform demonstration.</small>
  </footer>;
}
