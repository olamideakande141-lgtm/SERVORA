import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ children, admin = false }: { children: React.ReactNode; admin?: boolean }) {
  const { user, role, loading } = useAuth();
  if (loading) return <div className="page-center">Loading secure session…</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (admin && role !== "admin") return <Navigate to="/account" replace />;
  return <>{children}</>;
}
