import { MessageCircle } from "lucide-react";

export default function WhatsAppButton() {
  const number = import.meta.env.VITE_WHATSAPP_NUMBER as string | undefined;
  if (!number) return null;
  return <a className="whatsapp" href={`https://wa.me/${number}`} target="_blank" rel="noreferrer" aria-label="Contact on WhatsApp"><MessageCircle size={22} /></a>;
}
