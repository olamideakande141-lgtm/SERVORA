# Database setup

Run `supabase/migrations/001_initial_schema.sql` in the Supabase SQL Editor.

The migration creates profiles, business settings, services, bookings, booking notes, reviews and notifications, with indexes, a signup trigger and RLS policies.

For production, manage future schema changes as numbered migrations and test them in a staging Supabase project before applying them to a buyer's production project.
