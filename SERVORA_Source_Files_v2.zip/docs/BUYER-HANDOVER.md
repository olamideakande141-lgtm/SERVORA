# Buyer Handover Checklist

Before transferring this project to a buyer:

- Create a separate GitHub repository for the buyer.
- Create a separate Supabase project owned by the buyer.
- Apply the database migration.
- Configure buyer-owned environment variables.
- Create the buyer's first admin account.
- Replace logo, business name, contact details, currency and service catalogue.
- Test customer registration and booking.
- Test admin permissions and database access.
- Confirm the buyer controls the hosting, domain, repository and database.
- Remove all seller credentials and demo customer data.

Do not reuse one shared production database for unrelated buyers. Each buyer installation should have independent customer data.
