# Installation

## 1. Install dependencies
Install Node.js 20 or newer, clone the repository, then run:
```bash
npm install
```

## 2. Create Supabase project
Create a project at https://supabase.com. Open SQL Editor and run `supabase/migrations/001_initial_schema.sql`.

## 3. Configure environment
Copy `.env.example` to `.env` and fill in:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_WHATSAPP_NUMBER`

Only use the public anon key in the browser. Never use the service-role key in a VITE_ variable.

## 4. Create the first administrator
Register a normal user through the website. In Supabase SQL Editor, replace the email below with the exact email of the account you own:
```sql
update public.profiles
set role = 'admin'
where email = 'YOUR-ADMIN-EMAIL';
```
Run this manually as the project owner. Never expose this operation as a public website form.

## 5. Run
```bash
npm run dev
```
For production:
```bash
npm run build
```
Deploy the generated `dist` directory to a Vite-compatible static host and configure the same environment variables.

## 6. Verify
Test with two accounts: one customer and one administrator. Confirm customers cannot read other customers' bookings and cannot access admin functions.
