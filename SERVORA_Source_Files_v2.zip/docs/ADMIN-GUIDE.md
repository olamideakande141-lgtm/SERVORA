# Admin Guide

1. Sign in using the administrator account.
2. Open `/admin`.
3. Use Services to add, enable, disable or remove services.
4. Use Bookings to review appointment requests and update statuses.
5. Use Customers to view registered customer profiles.
6. Use Settings to update the business name, phone, WhatsApp number and currency.

Do not share administrator credentials. Use a unique account for each authorized administrator.
