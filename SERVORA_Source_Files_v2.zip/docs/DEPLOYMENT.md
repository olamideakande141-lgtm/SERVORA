# Deployment

1. Push the repository to GitHub.
2. Import it into a Vite-compatible host (Bolt hosting, Netlify, Vercel or another provider).
3. Set the environment variables from `.env.example`.
4. Set build command to `npm run build`.
5. Set output directory to `dist`.
6. Configure SPA fallback so application routes resolve to `index.html`.
7. Configure Supabase Auth Site URL and redirect URLs to the deployed domain.
8. Test login, booking and admin pages on the deployed domain.
