# Security notes

- The browser uses only the Supabase anon/public key.
- Never commit `.env` files.
- Never expose service-role keys.
- Database Row Level Security is required.
- The UI hiding an admin link is not security; database policies enforce access.
- Review RLS policies before adding new tables or features.
- Configure Supabase Auth email settings and allowed redirect URLs.
- Use HTTPS in production.
- Add rate limiting and abuse protection for public booking forms before high-volume launch.
- Perform a security review before handling sensitive customer or payment data.
