-- SERVORA initial schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.business_settings (
  id uuid primary key default gen_random_uuid(),
  business_name text not null default 'SERVORA',
  phone text,
  whatsapp_number text,
  currency text not null default 'USD',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price numeric(12,2) not null default 0 check (price >= 0),
  duration_minutes integer not null default 60 check (duration_minutes > 0),
  category text,
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id) on delete cascade,
  service_id uuid references public.services(id) on delete set null,
  service_name text not null,
  appointment_date date not null,
  appointment_time time not null,
  phone text,
  address text,
  notes text,
  amount numeric(12,2) not null default 0 check (amount >= 0),
  status text not null default 'pending' check (status in ('pending','confirmed','in_progress','completed','cancelled')),
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid','pending','paid','refunded')),
  created_at timestamptz not null default now()
);

create table if not exists public.booking_notes (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  admin_id uuid not null references public.profiles(id),
  note text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references public.profiles(id) on delete set null,
  rating integer not null check (rating between 1 and 5),
  comment text not null,
  approved boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists bookings_customer_id_idx on public.bookings(customer_id);
create index if not exists bookings_date_idx on public.bookings(appointment_date);
create index if not exists bookings_status_idx on public.bookings(status);
create index if not exists services_active_idx on public.services(active);

-- Create profile automatically on signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, full_name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Admin role check is performed inside PostgreSQL, not just in the UI.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

alter table public.profiles enable row level security;
alter table public.business_settings enable row level security;
alter table public.services enable row level security;
alter table public.bookings enable row level security;
alter table public.booking_notes enable row level security;
alter table public.reviews enable row level security;
alter table public.notifications enable row level security;

create policy "profiles read own or admin" on public.profiles for select
using (id = auth.uid() or public.is_admin());
create policy "profiles update own or admin" on public.profiles for update
using (id = auth.uid() or public.is_admin())
with check (id = auth.uid() or public.is_admin());

create policy "business settings readable" on public.business_settings for select using (true);
create policy "admins manage business settings" on public.business_settings for all
using (public.is_admin()) with check (public.is_admin());

create policy "active services readable" on public.services for select using (active = true or public.is_admin());
create policy "admins manage services" on public.services for all
using (public.is_admin()) with check (public.is_admin());

create policy "customers read own bookings or admins" on public.bookings for select
using (customer_id = auth.uid() or public.is_admin());
create policy "customers create own bookings" on public.bookings for insert
with check (customer_id = auth.uid());
create policy "admins update bookings" on public.bookings for update
using (public.is_admin()) with check (public.is_admin());
create policy "admins delete bookings" on public.bookings for delete using (public.is_admin());

create policy "admins manage booking notes" on public.booking_notes for all
using (public.is_admin()) with check (public.is_admin());

create policy "approved reviews readable" on public.reviews for select
using (approved = true or customer_id = auth.uid() or public.is_admin());
create policy "customers submit reviews" on public.reviews for insert
with check (customer_id = auth.uid());
create policy "admins manage reviews" on public.reviews for all
using (public.is_admin()) with check (public.is_admin());

create policy "users read own notifications" on public.notifications for select
using (user_id = auth.uid() or public.is_admin());
create policy "admins create notifications" on public.notifications for insert
with check (public.is_admin());
create policy "users update own notifications" on public.notifications for update
using (user_id = auth.uid() or public.is_admin())
with check (user_id = auth.uid() or public.is_admin());

insert into public.business_settings(business_name)
select 'SERVORA' where not exists(select 1 from public.business_settings);
