import { Navigate, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Pricing from "./pages/Pricing";
import Auth from "./pages/Auth";
import Workspace from "./pages/Workspace";
export default function App(){return <Routes><Route path="/" element={<Home/>}/><Route path="/pricing" element={<Pricing/>}/><Route path="/login" element={<Auth mode="login"/>}/><Route path="/signup" element={<Auth mode="signup"/>}/><Route path="/app" element={<Workspace/>}/><Route path="*" element={<Navigate to="/" replace/>}/></Routes>}