import { ArrowUpRight, CalendarCheck, ChartNoAxesCombined, ShieldCheck, Users } from "lucide-react";
import { Link } from "react-router-dom";
import Topbar from "../components/Topbar";
export default function Home() {
  return <><Topbar/><main>
    <section className="hero wrap"><div className="hero-copy"><div className="eyebrow"><span/> ONE PLATFORM. EVERY SERVICE BUSINESS.</div>
      <h1>Run your business.<br/><em>Beautifully.</em></h1>
      <p className="lead">Bookings, customers, services and business insights — brought together in one calm, powerful workspace.</p>
      <div className="hero-actions"><Link className="button" to="/signup">Create your business <ArrowUpRight size={17}/></Link><a className="button secondary" href="#features">Explore platform</a></div>
      <div className="trust"><ShieldCheck size={16}/> Business data separated with role-based access controls</div>
    </div><div className="dashboard-preview"><div className="preview-head"><div><small>WORKSPACE OVERVIEW</small><h3>Good morning, Alex</h3></div><span className="live-dot">● Live preview</span></div>
      <div className="preview-stats"><div><small>Appointments</small><b>128</b><i>+12.8%</i></div><div><small>Customers</small><b>864</b><i>+8.2%</i></div><div><small>Completed</small><b>96</b><i>+6.4%</i></div></div>
      <div className="chart"><div className="chart-label"><span>Booking activity</span><b>Last 7 days</b></div><div className="bars">{[38,62,48,82,58,92,70].map((v,i)=><div className="bar-col" key={i}><i style={{height:`${v}%`}}/><small>{["M","T","W","T","F","S","S"][i]}</small></div>)}</div></div>
      <div className="preview-booking"><span className="avatar">JD</span><div><b>Jordan Davis</b><small>Home cleaning · 10:30 AM</small></div><span className="status">Confirmed</span></div>
    </div></section>
    <section className="wrap feature-section" id="features"><div className="section-heading"><div className="eyebrow">BUILT FOR THE WAY YOU WORK</div><h2>Your business, <em>in control.</em></h2><p>Everything you need to deliver a better customer experience and stay organized.</p></div>
      <div className="feature-grid"><article><CalendarCheck/><h3>Smart bookings</h3><p>Manage appointments, availability and booking statuses in one place.</p></article><article><Users/><h3>Customer relationships</h3><p>Keep customer profiles and appointment history organized.</p></article><article><ChartNoAxesCombined/><h3>Clear business insights</h3><p>Understand your activity with practical reports and performance metrics.</p></article></div>
    </section>
    <section className="wrap how-section" id="how"><div><div className="eyebrow">GET STARTED IN MINUTES</div><h2>Set up once.<br/><em>Grow with clarity.</em></h2></div><ol><li><b>01</b><div><h3>Create your workspace</h3><p>Register your business and choose its identity.</p></div></li><li><b>02</b><div><h3>Add your services</h3><p>Set prices, durations and availability.</p></div></li><li><b>03</b><div><h3>Start taking bookings</h3><p>Share your booking page and manage requests.</p></div></li></ol></section>
    <section className="cta wrap"><div><div className="eyebrow">YOUR NEXT CHAPTER STARTS HERE</div><h2>Make room for <em>better business.</em></h2></div><Link className="button" to="/signup">Get started <ArrowUpRight size={17}/></Link></section>
  </main><footer className="footer wrap"><Link className="brand" to="/">SERVORA<span>.</span></Link><small>© {new Date().getFullYear()} SERVORA. Business, in good order.</small><Link to="/pricing">Plans & pricing</Link></footer></>;
}