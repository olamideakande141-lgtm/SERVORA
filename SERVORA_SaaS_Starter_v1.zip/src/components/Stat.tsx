export default function Stat({label,value,detail}:{label:string;value:string;detail:string}) {
  return <div className="stat-card"><span>{label}</span><strong>{value}</strong><small>{detail}</small></div>;
}