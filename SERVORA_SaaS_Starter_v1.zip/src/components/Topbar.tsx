import { Link } from "react-router-dom";
export default function Topbar() {
  return <header className="topbar"><Link className="brand" to="/">SERVORA<span>.</span></Link>
    <nav><a href="#features">Features</a><a href="#how">How it works</a><Link to="/pricing">Pricing</Link></nav>
    <div className="top-actions"><Link className="text-link" to="/login">Log in</Link><Link className="button small" to="/signup">Get started</Link></div>
  </header>;
}