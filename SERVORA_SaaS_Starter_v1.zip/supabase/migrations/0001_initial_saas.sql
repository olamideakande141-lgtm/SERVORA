-- SERVORA multi-tenant SaaS schema.
-- Apply in a fresh Supabase project using the SQL Editor or Supabase CLI.
create extension if not exists pgcrypto;

create type public.app_role as enum ('platform_admin','business_owner','staff','customer');
create type public.booking_status as enum ('pending','confirmed','in_progress','completed','cancelled');
create type public.subscription_status as enum ('trial','active','past_due','cancelled','expired','suspended');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.businesses (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  category text,
  description text,
  logo_url text,
  primary_color text not null default '#D4AF37',
  phone text,
  email text,
  whatsapp_number text,
  address text,
  currency text not null default 'NGN',
  timezone text not null default 'Africa/Lagos',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.business_members (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null check (role in ('business_owner','staff')),
  created_at timestamptz not null default now(),
  unique(business_id,user_id)
);

create table public.platform_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table public.service_categories (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now(),
  unique(business_id,name)
);

create table public.services (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  category_id uuid references public.service_categories(id) on delete set null,
  name text not null,
  description text,
  price_minor bigint not null default 0 check(price_minor >= 0),
  duration_minutes integer not null default 60 check(duration_minutes > 0),
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.business_hours (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  weekday smallint not null check(weekday between 0 and 6),
  opens_at time,
  closes_at time,
  is_closed boolean not null default false,
  unique(business_id,weekday)
);

create table public.blocked_dates (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  reason text,
  check(ends_at > starts_at)
);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  service_id uuid not null references public.services(id),
  customer_id uuid not null references auth.users(id),
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status public.booking_status not null default 'pending',
  customer_name text not null,
  customer_phone text not null,
  service_address text,
  customer_notes text,
  payment_status text not null default 'unpaid' check(payment_status in ('unpaid','pending','paid','refunded','failed')),
  created_at timestamptz not null default now(),
  check(ends_at > starts_at)
);
create index bookings_business_start_idx on public.bookings(business_id,starts_at);
create index bookings_customer_idx on public.bookings(customer_id,created_at desc);

create table public.booking_notes (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  author_id uuid not null references auth.users(id),
  note text not null,
  created_at timestamptz not null default now()
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid references auth.users(id),
  rating smallint not null check(rating between 1 and 5),
  body text,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.testimonials (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_name text not null,
  body text not null,
  rating smallint check(rating between 1 and 5),
  is_published boolean not null default false
);
create table public.faqs (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  question text not null,
  answer text not null,
  sort_order integer not null default 0,
  is_published boolean not null default true
);
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references public.businesses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.subscription_plans (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  monthly_price_minor bigint not null check(monthly_price_minor >= 0),
  yearly_price_minor bigint not null check(yearly_price_minor >= 0),
  currency text not null default 'NGN',
  limits jsonb not null default '{}'::jsonb,
  features jsonb not null default '[]'::jsonb,
  is_public boolean not null default true,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.business_subscriptions (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  plan_id uuid not null references public.subscription_plans(id),
  billing_interval text not null check(billing_interval in ('monthly','yearly')),
  status public.subscription_status not null default 'trial',
  starts_at timestamptz not null default now(),
  current_period_start timestamptz not null default now(),
  current_period_end timestamptz not null,
  cancel_at_period_end boolean not null default false,
  provider text,
  provider_customer_id text,
  provider_subscription_id text,
  created_at timestamptz not null default now()
);
create index subscriptions_business_idx on public.business_subscriptions(business_id,created_at desc);

create table public.subscription_payments (
  id uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references public.business_subscriptions(id) on delete cascade,
  business_id uuid not null references public.businesses(id) on delete cascade,
  provider text not null,
  provider_reference text not null unique,
  amount_minor bigint not null check(amount_minor >= 0),
  currency text not null,
  status text not null check(status in ('pending','successful','failed','refunded')),
  paid_at timestamptz,
  created_at timestamptz not null default now()
);
create table public.subscription_invoices (
  id uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references public.business_subscriptions(id) on delete cascade,
  invoice_number text not null unique,
  amount_minor bigint not null,
  currency text not null,
  status text not null,
  due_at timestamptz,
  paid_at timestamptz,
  created_at timestamptz not null default now()
);
create table public.subscription_events (
  id uuid primary key default gen_random_uuid(),
  subscription_id uuid references public.business_subscriptions(id) on delete set null,
  business_id uuid references public.businesses(id) on delete set null,
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create table public.payment_webhook_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_event_id text not null,
  payload jsonb not null,
  processed_at timestamptz,
  created_at timestamptz not null default now(),
  unique(provider,provider_event_id)
);

create table public.payment_records (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  booking_id uuid not null references public.bookings(id) on delete cascade,
  amount_minor bigint not null check(amount_minor >= 0),
  currency text not null,
  status text not null check(status in ('pending','successful','failed','refunded')),
  provider_reference text unique,
  confirmed_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.business_settings (
  business_id uuid primary key references public.businesses(id) on delete cascade,
  settings jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create or replace function public.is_platform_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.platform_admins where user_id=auth.uid()); $$;

create or replace function public.is_business_member(p_business_id uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.business_members where business_id=p_business_id and user_id=auth.uid()); $$;

create or replace function public.is_business_owner(p_business_id uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.business_members where business_id=p_business_id and user_id=auth.uid() and role='business_owner'); $$;

create or replace function public.create_business_workspace(p_name text,p_slug text)
returns uuid language plpgsql security definer set search_path=public
as $$
declare new_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if length(trim(p_name)) < 2 or length(p_name) > 100 then raise exception 'Business name must be 2–100 characters'; end if;
  if p_slug !~ '^[a-z0-9-]{3,50}$' then raise exception 'Slug must be 3–50 lowercase letters, numbers or hyphens'; end if;
  insert into public.businesses(name,slug) values(trim(p_name),p_slug) returning id into new_id;
  insert into public.business_members(business_id,user_id,role) values(new_id,auth.uid(),'business_owner');
  insert into public.business_settings(business_id) values(new_id);
  return new_id;
end; $$;

-- RLS: tenant isolation is enforced in the database, not only in the UI.
alter table public.profiles enable row level security;
alter table public.businesses enable row level security;
alter table public.business_members enable row level security;
alter table public.platform_admins enable row level security;
alter table public.service_categories enable row level security;
alter table public.services enable row level security;
alter table public.business_hours enable row level security;
alter table public.blocked_dates enable row level security;
alter table public.bookings enable row level security;
alter table public.booking_notes enable row level security;
alter table public.reviews enable row level security;
alter table public.testimonials enable row level security;
alter table public.faqs enable row level security;
alter table public.notifications enable row level security;
alter table public.subscription_plans enable row level security;
alter table public.business_subscriptions enable row level security;
alter table public.subscription_payments enable row level security;
alter table public.subscription_invoices enable row level security;
alter table public.subscription_events enable row level security;
alter table public.payment_webhook_events enable row level security;
alter table public.payment_records enable row level security;
alter table public.business_settings enable row level security;

create policy "profile self read" on public.profiles for select using(id=auth.uid() or public.is_platform_admin());
create policy "profile self update" on public.profiles for update using(id=auth.uid()) with check(id=auth.uid());
create policy "profile self insert" on public.profiles for insert with check(id=auth.uid());

create policy "business members read own" on public.businesses for select using(public.is_business_member(id) or public.is_platform_admin());
create policy "business owner update own" on public.businesses for update using(public.is_business_owner(id) or public.is_platform_admin()) with check(public.is_business_owner(id) or public.is_platform_admin());
create policy "business owner delete own" on public.businesses for delete using(public.is_business_owner(id) or public.is_platform_admin());

create policy "members read membership" on public.business_members for select using(user_id=auth.uid() or public.is_business_owner(business_id) or public.is_platform_admin());
create policy "owner manage members" on public.business_members for all using(public.is_business_owner(business_id) or public.is_platform_admin()) with check(public.is_business_owner(business_id) or public.is_platform_admin());

create policy "platform admin read admins" on public.platform_admins for select using(user_id=auth.uid() or public.is_platform_admin());

create policy "tenant service categories" on public.service_categories for all using(public.is_business_member(business_id) or public.is_platform_admin()) with check(public.is_business_member(business_id) or public.is_platform_admin());
create policy "public active services and tenant manage" on public.services for select using(is_active or public.is_business_member(business_id) or public.is_platform_admin());
create policy "tenant manage services" on public.services for all using(public.is_business_member(business_id) or public.is_platform_admin()) with check(public.is_business_member(business_id) or public.is_platform_admin());

create policy "tenant manage hours" on public.business_hours for all using(public.is_business_member(business_id) or public.is_platform_admin()) with check(public.is_business_member(business_id) or public.is_platform_admin());
create policy "tenant manage blocked dates" on public.blocked_dates for all using(public.is_business_member(business_id) or public.is_platform_admin()) with check(public.is_business_member(business_id) or public.is_platform_admin());

create policy "booking customer or tenant read" on public.bookings for select using(customer_id=auth.uid() or public.is_business_member(business_id) or public.is_platform_admin());
create policy "customer create booking" on public.bookings for insert with check(customer_id=auth.uid());
create policy "tenant update booking" on public.bookings for update using(public.is_business_member(business_id) or public.is_platform_admin()) with check(public.is_business_member(business_id) or public.is_platform_admin());

create policy "booking notes tenant read" on public.booking_notes for select using(exists(select 1 from public.bookings b where b.id=booking_id and (b.customer_id=auth.uid() or public.is_business_member(b.business_id) or public.is_platform_admin())));
create policy "tenant add booking notes" on public.booking_notes for insert with check(author_id=auth.uid() and exists(select 1 from public.bookings b where b.id=booking_id and (public.is_business_member(b.business_id) or public.is_platform_admin())));

create policy "reviews public published or tenant" on public.reviews for select using(is_published or customer_id=auth.uid() or public.is_business_member(business_id) or public.is_platform_admin());
create policy "customer create own review" on public.reviews for insert with check(customer_id=auth.uid());
create policy "tenant moderate reviews" on public.reviews for update using(public.is_business_member(business_id) or public.is_platform_admin()) with check(public.is_business_member(business_id) or public.is_platform_admin());

create policy "published testimonials visible" on public.testimonials for select using(is_published or public.is_business_member(business_id) or public.is_platform_admin());
create policy "tenant manage testimonials" on public.testimonials for all using(public.is_business_member(business_id) or public.is_platform_admin()) with check(public.is_business_member(business_id) or public.is_platform_admin());
create policy "published faqs visible" on public.faqs for select using(is_published or public.is_business_member(business_id) or public.is_platform_admin());
create policy "tenant manage faqs" on public.faqs for all using(public.is_business_member(business_id) or public.is_platform_admin()) with check(public.is_business_member(business_id) or public.is_platform_admin());

create policy "user notifications" on public.notifications for select using(user_id=auth.uid() or public.is_platform_admin());
create policy "user update notifications" on public.notifications for update using(user_id=auth.uid()) with check(user_id=auth.uid());

create policy "public active plans" on public.subscription_plans for select using((is_public and is_active) or public.is_platform_admin());
create policy "platform manage plans" on public.subscription_plans for all using(public.is_platform_admin()) with check(public.is_platform_admin());

create policy "tenant subscriptions read" on public.business_subscriptions for select using(public.is_business_member(business_id) or public.is_platform_admin());
create policy "platform manage subscriptions" on public.business_subscriptions for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "tenant payments read" on public.subscription_payments for select using(public.is_business_member(business_id) or public.is_platform_admin());
create policy "platform manage subscription payments" on public.subscription_payments for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "tenant invoices read" on public.subscription_invoices for select using(exists(select 1 from public.business_subscriptions s where s.id=subscription_id and public.is_business_member(s.business_id)) or public.is_platform_admin());
create policy "platform manage invoices" on public.subscription_invoices for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "tenant subscription events read" on public.subscription_events for select using(public.is_business_member(business_id) or public.is_platform_admin());
create policy "platform manage events" on public.subscription_events for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "webhook events admin only" on public.payment_webhook_events for all using(public.is_platform_admin()) with check(public.is_platform_admin());

create policy "tenant payment records read" on public.payment_records for select using(public.is_business_member(business_id) or exists(select 1 from public.bookings b where b.id=booking_id and b.customer_id=auth.uid()) or public.is_platform_admin());
create policy "tenant manage payment records" on public.payment_records for all using(public.is_business_member(business_id) or public.is_platform_admin()) with check(public.is_business_member(business_id) or public.is_platform_admin());

create policy "tenant business settings" on public.business_settings for all using(public.is_business_member(business_id) or public.is_platform_admin()) with check(public.is_business_member(business_id) or public.is_platform_admin());

-- Important production hardening before launch:
-- 1. Use a server-side booking function with transaction/locking to prevent overlapping bookings.
-- 2. Add customer/business membership model for public booking without allowing forged customer_id.
-- 3. Create platform_admins only through trusted SQL/service-role operations; never expose admin enrollment.
-- 4. Add payment-provider webhook Edge Functions that verify signatures and idempotency.
-- 5. Review and test every policy for your exact customer/staff access rules.
